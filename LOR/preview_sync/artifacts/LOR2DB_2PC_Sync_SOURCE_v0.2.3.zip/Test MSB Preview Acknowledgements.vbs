Option Explicit
Dim fso, shell, root, snapshotRoot, snapshotFolder, sourceXml, copyXml, program, powershell, arguments
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
root = fso.GetParentFolderName(WScript.ScriptFullName)
sourceXml = "C:\lor\CommonData\LORPreviews.xml"
program = fso.BuildPath(root, "Update_MSB_Previews.ps1")
powershell = shell.ExpandEnvironmentStrings("%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe")
If Not fso.FileExists(sourceXml) Or Not fso.FileExists(program) Then
    MsgBox "The local preview library or test program is missing. Nothing was changed.", vbCritical, "MSB Comparison Test"
    WScript.Quit 2
End If
snapshotRoot = fso.BuildPath(root, "AcceptanceSnapshots")
If Not fso.FolderExists(snapshotRoot) Then fso.CreateFolder snapshotRoot
snapshotFolder = fso.BuildPath(snapshotRoot, fso.GetTempName)
fso.CreateFolder snapshotFolder
copyXml = fso.BuildPath(snapshotFolder, "LORPreviews.xml")
fso.CopyFile sourceXml, copyXml, False
arguments = "-NoLogo -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File " & _
    Chr(34) & program & Chr(34) & " -Root " & Chr(34) & root & Chr(34) & _
    " -LocalXml " & Chr(34) & copyXml & Chr(34) & " -ReviewOnly"
shell.Run Chr(34) & powershell & Chr(34) & " " & arguments, 0, False
