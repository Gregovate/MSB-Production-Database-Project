MSB LOR PREVIEW UPDATE
======================

Shared programmer folder
------------------------
G:\Shared drives\MSB Database\UserPreviewStaging\LOR2DB_2PC_Sync

One-time setup by Greg / MSB database administrator
---------------------------------------------------
1. Put this package's files directly in the shared folder above.
2. Put the latest completed LOR2DB reconciliation HTML report(s) in:
       LOR2DB_Reports
3. Double-click:
       Install MSB Preview Update Shortcut.vbs
4. Windows creates the official shared shortcut with the MSB Preview Update icon:
       Update your PC Previews to LOR Master Files.lnk
5. Explorer opens automatically and highlights the shortcut. You do NOT choose any folders.

Normal programmer instructions
------------------------------
1. Close Light-O-Rama.
2. Open the shared LOR2DB_2PC_Sync folder.
3. Double-click:
       Update your PC Previews to LOR Master Files
4. Read the plain-English review.
5. If controlled MSB previews differ, acknowledge the overwrite warning.
6. Click Update PC Previews.
7. Reopen Light-O-Rama.

No PowerShell, Python, Git, XML, or command line is part of the normal operator workflow.

Safety
------
- The latest COMPLETED LOR2DB reconciliation report identifies the accepted source folder.
- The source folder is validated against the report before synchronization.
- Every controlled PreviewID must be accounted for.
- Revision-only differences do not cause replacement.
- Master substantive content wins during MASTER -> LOCAL synchronization.
- Personal/unmanaged PreviewClass blocks are preserved byte-for-byte.
- Duplicate controlled PreviewIDs block the update.
- A timestamped backup is created before the live XML is replaced.
- The live XML is replaced only with Light-O-Rama closed and after operator acknowledgement.

Troubleshooting
---------------
If the launcher fails, it now shows the PowerShell error instead of only an exit code and writes:
       logs\launcher-latest.log


2026-10-04 v0.1.5 compatibility fix:
- removed .NET Generic.List use that can fail under Windows PowerShell 5.1 with "Argument types do not match";
- the shortcut icon now uses a new tree/star icon pathname to bypass Windows Explorer's old icon cache;
- handled PowerShell errors show one dialog and write logs\powershell-error-latest.log.


0.1.6 launch acceptance fix:
- Renamed internal preview-ID variable from $pid to $previewId because Windows PowerShell treats $PID as a built-in read-only variable.


0.1.7 launcher simplification:
- The official .lnk now launches Update_MSB_Previews.ps1 directly through Windows PowerShell.
- Removed Launch_Update_MSB_Previews.vbs from the normal/runtime path.
- This avoids the abnormal 0xC000013A / -1073741510 child-process termination seen through WScript.Shell.Exec.


0.1.8 installer compatibility fix:
- Rewrote Install MSB Preview Update Shortcut.vbs as plain ASCII with no UTF-8 BOM.
- Fixes Windows Script Host error 800A0408: Invalid character, line 1 char 1.


0.1.9 launch-safety fix:
- First click immediately shows a Starting MSB Preview Update window.
- Startup status advances through report discovery, master validation, and local comparison.
- A named Windows mutex blocks a second copy from starting while the first is running.
- Repeated double-clicks now show a simple already-open message instead of spawning more writers.


0.2.0 launch-safety acceptance fix:
- Replaced the failed named-mutex guard with an exclusive file-handle lock under %LOCALAPPDATA%\MSB.
- The first click must visibly show Starting MSB Preview Update before any comparison work runs.
- A second click while the first copy is alive is blocked with an already-open message.
- The review window is explicitly brought to the foreground so it cannot quietly open behind Explorer.


0.2.1 startup/performance fix:
- Master files are no longer reread during Run validation.
- Semantic XML hashing now runs in compiled .NET code rather than recursive PowerShell.
- Startup displays the actual preview being loaded/checked/compared so it should remain visibly alive.
- No change to master authority, revision-only handling, controlled overwrite rules, backups, or unmanaged preview preservation.
