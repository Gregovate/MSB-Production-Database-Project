Option Explicit

Dim shell, fso, root, shortcutPath, scriptPath, iconPath, powershellPath, link
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

root = fso.GetParentFolderName(WScript.ScriptFullName)
scriptPath = fso.BuildPath(root, "Update_MSB_Previews.ps1")
iconPath = fso.BuildPath(root, "MSB Preview Update Tree v2.ico")
shortcutPath = fso.BuildPath(root, "Update your PC Previews to LOR Master Files.lnk")
powershellPath = shell.ExpandEnvironmentStrings("%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe")

If Not fso.FileExists(scriptPath) Then
    MsgBox "Cannot create the MSB Preview Update shortcut." & vbCrLf & vbCrLf & _
           "Missing program:" & vbCrLf & scriptPath, _
           vbCritical, "MSB Preview Update"
    WScript.Quit 2
End If

If Not fso.FileExists(iconPath) Then
    MsgBox "Cannot create the MSB Preview Update shortcut." & vbCrLf & vbCrLf & _
           "Missing icon:" & vbCrLf & iconPath, _
           vbCritical, "MSB Preview Update"
    WScript.Quit 2
End If

If Not fso.FileExists(powershellPath) Then
    MsgBox "Windows PowerShell was not found on this PC:" & vbCrLf & vbCrLf & _
           powershellPath, vbCritical, "MSB Preview Update"
    WScript.Quit 2
End If

' Remove obsolete files from earlier acceptance builds so programmers
' see only the supported launcher and current support files.
Dim obsoleteFiles, oldName, oldPath
obsoleteFiles = Array( _
    "Launch_Update_MSB_Previews.vbs", _
    "MSB Preview Update - DIAGNOSTIC.cmd", _
    "MSB Preview Update.ico", _
    "Update your PC Previews to LOR Master Files.cmd" _
)
For Each oldName In obsoleteFiles
    oldPath = fso.BuildPath(root, CStr(oldName))
    If fso.FileExists(oldPath) Then
        On Error Resume Next
        fso.DeleteFile oldPath, True
        On Error GoTo 0
    End If
Next

If fso.FileExists(shortcutPath) Then
    fso.DeleteFile shortcutPath, True
End If

Set link = shell.CreateShortcut(shortcutPath)
link.TargetPath = powershellPath
link.Arguments = "-NoLogo -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File " & _
                 Chr(34) & scriptPath & Chr(34)
link.WorkingDirectory = root
link.Description = "Update your PC Previews to LOR Master Files"
link.WindowStyle = 7
link.IconLocation = iconPath & ",0"
link.Save

If fso.FileExists(shortcutPath) Then
    MsgBox "Shortcut created successfully." & vbCrLf & vbCrLf & _
           "Programmers should double-click:" & vbCrLf & _
           "Update your PC Previews to LOR Master Files" & vbCrLf & vbCrLf & _
           "This shortcut now launches the MSB update program directly." & vbCrLf & _
           "No command window or folder selection is required.", _
           vbInformation, "MSB Preview Update"

    shell.Run "explorer.exe /select," & Chr(34) & shortcutPath & Chr(34), 1, False
    WScript.Quit 0
Else
    MsgBox "Windows did not create the shortcut." & vbCrLf & vbCrLf & _
           "Contact the MSB database administrator.", _
           vbCritical, "MSB Preview Update"
    WScript.Quit 2
End If
