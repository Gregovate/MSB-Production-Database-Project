Option Explicit
Dim fso, shell, root, program, powershell, arguments
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
root = fso.GetParentFolderName(WScript.ScriptFullName)
program = fso.BuildPath(root, "Update_MSB_Previews.ps1")
powershell = shell.ExpandEnvironmentStrings("%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe")
arguments = "-NoLogo -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File " & Chr(34) & program & Chr(34)
shell.Run Chr(34) & powershell & Chr(34) & " " & arguments, 0, False