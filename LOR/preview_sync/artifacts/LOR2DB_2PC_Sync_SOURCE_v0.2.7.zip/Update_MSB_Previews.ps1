﻿# MSB LOR Preview Sync - Phase 1 v0.2.7
# Programmer-facing MASTER -> LOCAL synchronization tool.
#
# Normal operators launch this through:
#   Update your PC Previews to LOR Master Files (Windows shortcut)
#
# The script:
# - discovers the latest COMPLETED LOR2DB reconciliation report in LOR2DB_Reports;
# - validates the exact versioned master folder recorded by that report;
# - compares controlled previews by PreviewClass.id and substantive content;
# - ignores revision-only differences;
# - preserves all personal/unmanaged PreviewClass blocks byte-for-byte;
# - requires acknowledgement before overwriting substantively different local MSB previews;
# - backs up the local LORPreviews.xml before apply;
# - atomically replaces the local file only after validation.
#
# It does NOT update the versioned master folder and does NOT change LOR2DB state.

[CmdletBinding()]
param(
    [string]$Root = '',
    [string]$LocalXml = 'C:\lor\CommonData\LORPreviews.xml',
    [switch]$AuditOnly,
    [switch]$ReviewOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Resolve the script root after parameter binding. Windows PowerShell 5.1 can
# evaluate $PSScriptRoot as empty when it is used as a parameter default under
# some launcher paths, which makes Join-Path fail before the UI starts.
if ([string]::IsNullOrWhiteSpace($Root)) {
    $Root = $PSScriptRoot
}
if ([string]::IsNullOrWhiteSpace($Root) -and $MyInvocation.MyCommand.Path) {
    $Root = Split-Path -Parent $MyInvocation.MyCommand.Path
}
if ([string]::IsNullOrWhiteSpace($Root)) {
    throw 'The MSB Preview Update could not determine its shared-folder location.'
}

if ([string]::IsNullOrWhiteSpace($LocalXml)) {
    throw 'The local Light-O-Rama preview-library path is empty.'
}
$localParent = Split-Path -Parent $LocalXml
if ([string]::IsNullOrWhiteSpace($localParent)) {
    throw "The local Light-O-Rama preview-library folder could not be determined: $LocalXml"
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# Compile the semantic PreviewClass reader once per launch. It implements the
# same comparison contract as the original PowerShell code: root Revision is
# ignored, attributes are compared independent of ordering, whitespace-only
# text is ignored, and all substantive element/text content is hashed.
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Xml;

public static class MSBTaskbarIdentity
{
    [System.Runtime.InteropServices.DllImport("shell32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
    public static extern int SetCurrentProcessExplicitAppUserModelID(string appId);
}

public sealed class MSBPreviewInfo
{
    public string PreviewId { get; set; }
    public string Name { get; set; }
    public string Revision { get; set; }
    public string SemanticHash { get; set; }
}

public static class MSBPreviewSemantic
{
    private static void AddToken(StringBuilder builder, string kind, string value)
    {
        if (value == null) value = "";
        builder.Append(kind);
        builder.Append(':');
        builder.Append(value.Length);
        builder.Append(':');
        builder.Append(value);
        builder.Append(';');
    }

    private static void AddNode(XmlNode node, StringBuilder builder, bool isRoot)
    {
        AddToken(builder, "E", node.LocalName);

        if (node.Attributes != null)
        {
            List<XmlAttribute> attrs = new List<XmlAttribute>();
            foreach (XmlAttribute attr in node.Attributes)
            {
                if (isRoot && String.Equals(attr.LocalName, "Revision", StringComparison.OrdinalIgnoreCase))
                    continue;
                attrs.Add(attr);
            }
            attrs.Sort((a, b) => StringComparer.Ordinal.Compare(a.Name, b.Name));

            foreach (XmlAttribute attr in attrs)
            {
                AddToken(builder, "A", attr.LocalName);
                AddToken(builder, "V", attr.Value);
            }
        }

        foreach (XmlNode child in node.ChildNodes)
        {
            if (child.NodeType == XmlNodeType.Element)
            {
                AddNode(child, builder, false);
            }
            else if (child.NodeType == XmlNodeType.Text || child.NodeType == XmlNodeType.CDATA)
            {
                string value = child.Value ?? "";
                if (!String.IsNullOrWhiteSpace(value))
                    AddToken(builder, "T", value);
            }
        }

        AddToken(builder, "X", node.LocalName);
    }

    private static string Sha256(string value)
    {
        using (SHA256 sha = SHA256.Create())
        {
            byte[] bytes = Encoding.UTF8.GetBytes(value);
            byte[] digest = sha.ComputeHash(bytes);
            StringBuilder result = new StringBuilder(digest.Length * 2);
            foreach (byte b in digest)
                result.Append(b.ToString("x2"));
            return result.ToString();
        }
    }

    public static MSBPreviewInfo Parse(string raw, string source)
    {
        XmlDocument doc = new XmlDocument();
        doc.PreserveWhitespace = true;
        doc.LoadXml(raw);

        XmlElement node = doc.DocumentElement;
        if (node == null || !String.Equals(node.LocalName, "PreviewClass", StringComparison.Ordinal))
            throw new InvalidOperationException("Preview fragment is not PreviewClass: " + source);

        string id = node.GetAttribute("id");
        if (String.IsNullOrEmpty(id)) id = node.GetAttribute("ID");
        if (String.IsNullOrEmpty(id)) id = node.GetAttribute("Id");
        if (String.IsNullOrEmpty(id))
            throw new InvalidOperationException("PreviewClass has no id/ID/Id: " + source);

        StringBuilder builder = new StringBuilder();
        AddNode(node, builder, true);

        return new MSBPreviewInfo {
            PreviewId = id.ToLowerInvariant(),
            Name = node.GetAttribute("Name"),
            Revision = node.GetAttribute("Revision"),
            SemanticHash = Sha256(builder.ToString())
        };
    }
}
'@ -ReferencedAssemblies 'System.Xml.dll', 'System.Core.dll'

# Separate the WinForms app from PowerShell taskbar grouping before any windows exist.
[System.Runtime.InteropServices.Marshal]::ThrowExceptionForHR([MSBTaskbarIdentity]::SetCurrentProcessExplicitAppUserModelID('MSB.LOR.PreviewSync'))

# Prevent repeated double-clicks from starting multiple writers against the
# same candidate/report files. An exclusive file handle is held for the entire
# lifetime of this PowerShell process. Windows releases it automatically if the
# process exits or crashes, so there is no stale-lock cleanup problem.
$script:InstanceLockStream = $null
$instanceLockFolder = Join-Path $env:LOCALAPPDATA 'MSB'
$instanceLockPath = Join-Path $instanceLockFolder 'LORPreviewUpdate.instance.lock'

try {
    if (-not (Test-Path -LiteralPath $instanceLockFolder -PathType Container)) {
        [void][System.IO.Directory]::CreateDirectory($instanceLockFolder)
    }

    $script:InstanceLockStream = [System.IO.File]::Open(
        $instanceLockPath,
        [System.IO.FileMode]::OpenOrCreate,
        [System.IO.FileAccess]::ReadWrite,
        [System.IO.FileShare]::None
    )
}
catch [System.IO.IOException] {
    [void][System.Windows.Forms.MessageBox]::Show(
        "MSB Preview Update is already starting or open on this PC.`r`n`r`nPlease use the existing window.",
        'MSB Preview Update',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    )
    exit 0
}
catch {
    [void][System.Windows.Forms.MessageBox]::Show(
        "MSB Preview Update could not create its single-instance safety lock.`r`n`r`n" +
        $_.Exception.Message + "`r`n`r`nNothing was changed.",
        'MSB Preview Update Blocked',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    )
    exit 2
}

$AppIconPath = Join-Path $Root 'MSB Preview Update Tree v2.ico'
$script:AppIcon = $null
if (Test-Path -LiteralPath $AppIconPath -PathType Leaf) {
    try {
        $script:AppIcon = New-Object System.Drawing.Icon($AppIconPath)
    }
    catch {
        $script:AppIcon = $null
    }
}

$ReportFolder = Join-Path $Root 'LOR2DB_Reports'
$LogFolder = Join-Path $Root 'logs'
$CandidateXml = Join-Path $localParent 'LORPreviews.MSB_SYNC_CANDIDATE.xml'
$CandidateCsv = Join-Path $localParent 'LORPreviews.MSB_SYNC_REPORT.csv'

$PreviewBlockPattern = '<PreviewClass\b[^>]*\bid=["''](?<id>[^"'']+)["''][^>]*>.*?</PreviewClass>'
$RegexOptions = [System.Text.RegularExpressions.RegexOptions]::IgnoreCase -bor [System.Text.RegularExpressions.RegexOptions]::Singleline

function Show-Message {
    param(
        [Parameter(Mandatory=$true)][string]$Text,
        [string]$Title = 'MSB LOR Preview Update',
        [System.Windows.Forms.MessageBoxIcon]$Icon = [System.Windows.Forms.MessageBoxIcon]::Information
    )

    [void][System.Windows.Forms.MessageBox]::Show(
        $Text,
        $Title,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        $Icon
    )
}

function Get-CleanHtmlText {
    param([string]$Value)
    $withoutTags = [regex]::Replace($Value, '<[^>]+>', '')
    return [System.Net.WebUtility]::HtmlDecode($withoutTags).Trim()
}

function Read-AcceptedReport {
    param([Parameter(Mandatory=$true)][string]$Path)

    $text = Get-Content -LiteralPath $Path -Raw -Encoding UTF8

    if ($text -notmatch '<body\b[^>]*data-report-outcome=["'']COMPLETED["'']') {
        return $null
    }

    $runMatch = [regex]::Match(
        $text,
        'LOR Production Reconciliation Report\s*(?:\u2014|-)\s*Run\s+(\d+)',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )
    $sourceMatch = [regex]::Match(
        $text,
        '<strong>\s*Source folder:\s*</strong>\s*([^<]+)',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )
    $sectionMatch = [regex]::Match(
        $text,
        '<h2>\s*3\.\s*Source Preview Files\s*</h2>(.*?)(?=<h2>\s*4\.)',
        $RegexOptions
    )

    if (-not $runMatch.Success -or -not $sourceMatch.Success -or -not $sectionMatch.Success) {
        return $null
    }

    $tableMatch = [regex]::Match($sectionMatch.Groups[1].Value, '<table\b[^>]*>(.*?)</table>', $RegexOptions)
    if (-not $tableMatch.Success) {
        return $null
    }

    $rows = @()
    foreach ($rowMatch in [regex]::Matches($tableMatch.Groups[1].Value, '<tr\b[^>]*>(.*?)</tr>', $RegexOptions)) {
        $cells = @()
        foreach ($cellMatch in [regex]::Matches($rowMatch.Groups[1].Value, '<t[dh]\b[^>]*>(.*?)</t[dh]>', $RegexOptions)) {
            $cells += Get-CleanHtmlText $cellMatch.Groups[1].Value
        }

        if ($cells.Count -lt 5) { continue }
        if ($cells[0] -ieq 'Preview filename') { continue }

        $rows += [pscustomobject]@{
            Filename    = $cells[0]
            Revision    = $cells[1]
            PreviewName = $cells[2]
            Stage       = $cells[3]
            Brightness  = $cells[4]
        }
    }

    if ($rows.Count -eq 0) {
        return $null
    }

    return [pscustomobject]@{
        Path         = $Path
        RunId        = [int]$runMatch.Groups[1].Value
        SourceFolder = [System.Net.WebUtility]::HtmlDecode($sourceMatch.Groups[1].Value).Trim()
        Rows         = $rows
    }
}

function Get-LatestAcceptedReport {
    param([Parameter(Mandatory=$true)][string]$Folder)

    if (-not (Test-Path -LiteralPath $Folder -PathType Container)) {
        throw "LOR2DB report folder was not found:`n$Folder"
    }

    $accepted = @()
    foreach ($file in @(Get-ChildItem -LiteralPath $Folder -Filter '*.html' -File)) {
        $report = Read-AcceptedReport -Path ([string]$file.FullName)
        if ($null -ne $report) {
            $accepted += $report
        }
    }

    if ($accepted.Count -eq 0) {
        throw "No COMPLETED LOR2DB reconciliation reports were found in:`n$Folder"
    }

    return $accepted | Sort-Object RunId -Descending | Select-Object -First 1
}

function Add-Token {
    param(
        [Parameter(Mandatory=$true)][System.Text.StringBuilder]$Builder,
        [Parameter(Mandatory=$true)][string]$Kind,
        [AllowNull()][string]$Value
    )

    if ($null -eq $Value) { $Value = '' }
    [void]$Builder.Append($Kind)
    [void]$Builder.Append(':')
    [void]$Builder.Append($Value.Length)
    [void]$Builder.Append(':')
    [void]$Builder.Append($Value)
    [void]$Builder.Append(';')
}

function Add-SemanticNode {
    param(
        [Parameter(Mandatory=$true)][System.Xml.XmlNode]$Node,
        [Parameter(Mandatory=$true)][System.Text.StringBuilder]$Builder,
        [bool]$IsRoot = $false
    )

    Add-Token $Builder 'E' $Node.LocalName

    if ($Node.Attributes) {
        $attrs = @($Node.Attributes | Sort-Object Name)
        foreach ($attr in $attrs) {
            if ($IsRoot -and $attr.LocalName -ieq 'Revision') {
                continue
            }
            Add-Token $Builder 'A' $attr.LocalName
            Add-Token $Builder 'V' $attr.Value
        }
    }

    foreach ($child in @($Node.ChildNodes)) {
        if ($child.NodeType -eq [System.Xml.XmlNodeType]::Element) {
            Add-SemanticNode $child $Builder $false
        }
        elseif ($child.NodeType -in @(
            [System.Xml.XmlNodeType]::Text,
            [System.Xml.XmlNodeType]::CDATA
        )) {
            $value = [string]$child.Value
            if (-not [string]::IsNullOrWhiteSpace($value)) {
                Add-Token $Builder 'T' $value
            }
        }
    }

    Add-Token $Builder 'X' $Node.LocalName
}

function Get-Sha256String {
    param([Parameter(Mandatory=$true)][string]$Text)

    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
        return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant()
    }
    finally {
        $sha.Dispose()
    }
}

function Get-PreviewRecord {
    param(
        [Parameter(Mandatory=$true)][string]$Raw,
        [Parameter(Mandatory=$true)][string]$Source
    )

    $info = [MSBPreviewSemantic]::Parse($Raw, $Source)

    return [pscustomobject]@{
        PreviewId    = $info.PreviewId
        Name         = $info.Name
        Revision     = $info.Revision
        SemanticHash = $info.SemanticHash
        Raw          = $Raw
        Source       = $Source
    }
}

function Remove-XmlDeclaration {
    param([string]$Text)
    $withoutBom = $Text.TrimStart([char]0xFEFF)
    return [regex]::Replace($withoutBom, '^\s*<\?xml[^>]*\?>\s*', '', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase).Trim()
}

function Get-MasterRecords {
    param(
        [Parameter(Mandatory=$true)][string]$Folder,
        [AllowNull()]$ProgressWindow
    )

    if (-not (Test-Path -LiteralPath $Folder -PathType Container)) {
        throw "Master preview folder is not available on this PC:`n$Folder"
    }

    $files = @(Get-ChildItem -LiteralPath $Folder -Filter '*.lorprev' -File | Sort-Object Name)
    if ($files.Count -eq 0) {
        throw "No .lorprev files were found in the master folder:`n$Folder"
    }

    $records = @{}
    $fileMap = @{}
    $fileRecords = @{}
    $index = 0

    foreach ($file in $files) {
        $index += 1
        if ($null -ne $ProgressWindow) {
            Set-StartupStatus -Window $ProgressWindow -Text (
                "Reading approved master preview {0} of {1}: {2}" -f $index, $files.Count, $file.Name
            )
        }

        # Read each Google Drive master file exactly once. The parsed record is
        # retained for both reconciliation-report validation and local comparison.
        $masterBytes = [IO.File]::ReadAllBytes($file.FullName)
        $raw = Remove-XmlDeclaration ([Text.Encoding]::UTF8.GetString($masterBytes))
        $record = Get-PreviewRecord -Raw $raw -Source ([string]$file.FullName)

        if ($records.ContainsKey($record.PreviewId)) {
            throw "Duplicate controlled PreviewID $($record.PreviewId) in master folder."
        }

        $sha = [Security.Cryptography.SHA256]::Create()
        try { $rawHash = ([BitConverter]::ToString($sha.ComputeHash($masterBytes))).Replace('-', '').ToLowerInvariant() } finally { $sha.Dispose() }
        $record | Add-Member -NotePropertyName RawFileHash -NotePropertyValue $rawHash
        $key = $file.Name.ToLowerInvariant()
        $records[$record.PreviewId] = $record
        $fileMap[$key] = $file.FullName
        $fileRecords[$key] = $record
    }

    return [pscustomobject]@{
        Records     = $records
        Files       = $fileMap
        FileRecords = $fileRecords
        Count       = $files.Count
    }
}

function Test-MasterAgainstReport {
    param(
        [Parameter(Mandatory=$true)]$Report,
        [Parameter(Mandatory=$true)]$Master,
        [AllowNull()]$ProgressWindow
    )

    if ($Report.Rows.Count -ne $Master.Count) {
        throw "The master folder count does not match LOR2DB Run $($Report.RunId).`nReport: $($Report.Rows.Count)`nFolder: $($Master.Count)"
    }

    $manifestPath = Join-Path $Report.SourceFolder '_MSB_CONTROLLED_PREVIEW_MANIFEST.csv'
    if (-not (Test-Path -LiteralPath $manifestPath)) { throw 'Controlled master manifest is missing. Nothing was installed.' }
    $manifest = @(Import-Csv -LiteralPath $manifestPath)
    if ($manifest.Count -ne $Master.Count) { throw 'Controlled manifest count does not match master files.' }
    $seenManifest = @{}
    foreach ($manifestRow in $manifest) {
        $manifestKey = $manifestRow.filename.ToLowerInvariant()
        if ($seenManifest.ContainsKey($manifestKey) -or -not $Master.FileRecords.ContainsKey($manifestKey)) { throw 'Controlled manifest contains duplicate or unknown filenames.' }
        $seenManifest[$manifestKey] = $true
        $manifestRecord = $Master.FileRecords[$manifestKey]
        if ($manifestRecord.PreviewId -ne $manifestRow.preview_id -or $manifestRecord.Name -ne $manifestRow.preview_name -or $manifestRecord.RawFileHash -ne $manifestRow.file_sha256) {
            throw "Master identity/content differs from the controlled manifest: $($manifestRow.filename). Review the controlled source before updating this PC."
        }
    }
    $reportNames = @{}
    foreach ($row in $Report.Rows) {
        $reportNames[$row.Filename.ToLowerInvariant()] = $row
    }

    $missing = @($reportNames.Keys | Where-Object { -not $Master.Files.ContainsKey($_) })
    $extra = @($Master.Files.Keys | Where-Object { -not $reportNames.ContainsKey($_) })

    if ($missing.Count -gt 0 -or $extra.Count -gt 0) {
        throw "The master folder file list does not match LOR2DB Run $($Report.RunId).`nMissing: $($missing -join ', ')`nExtra: $($extra -join ', ')"
    }

    $index = 0
    foreach ($row in $Report.Rows) {
        $index += 1
        if ($null -ne $ProgressWindow) {
            Set-StartupStatus -Window $ProgressWindow -Text (
                "Checking Run {0} evidence {1} of {2}: {3}" -f $Report.RunId, $index, $Report.Rows.Count, $row.Filename
            )
        }

        $key = $row.Filename.ToLowerInvariant()
        $record = $Master.FileRecords[$key]

        if ($null -eq $record) {
            throw "The parsed master record was not retained for $($row.Filename)."
        }

        if ($record.Name -ne $row.PreviewName) {
            throw "Preview name mismatch for $($row.Filename).`nReport: $($row.PreviewName)`nFile: $($record.Name)"
        }

        if ($record.Revision -ne $row.Revision) {
            throw "Revision mismatch for $($row.Filename).`nReport: $($row.Revision)`nFile: $($record.Revision)"
        }
    }
}

function Get-NewlineStyle {
    param([string]$Text)
    if ($Text.Contains("`r`n")) { return "`r`n" }
    return "`n"
}

function Add-IndentToFragment {
    param(
        [string]$Fragment,
        [string]$Indent,
        [string]$Newline
    )

    $normalized = $Fragment.Replace("`r`n", "`n").Replace("`r", "`n")
    $lines = $normalized -split "`n", -1

    if ($lines.Count -le 1) { return $Fragment }

    $result = @($lines[0])
    for ($i = 1; $i -lt $lines.Count; $i++) {
        $result += ($Indent + $lines[$i])
    }
    return ($result -join $Newline)
}

function Build-SyncCandidate {
    param(
        [Parameter(Mandatory=$true)]$MasterRecords,
        [Parameter(Mandatory=$true)][string]$LocalPath,
        [AllowNull()]$ProgressWindow
    )

    if (-not (Test-Path -LiteralPath $LocalPath -PathType Leaf)) {
        throw "Local LOR preview library was not found:`n$LocalPath"
    }

    if ($null -ne $ProgressWindow) { Set-StartupStatus -Window $ProgressWindow -Text 'Reading your local preview library...' }
    $bytes = [System.IO.File]::ReadAllBytes($LocalPath)
    $hadBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
    $localText = [System.Text.Encoding]::UTF8.GetString($bytes)
    if ($hadBom -and $localText.Length -gt 0 -and $localText[0] -eq [char]0xFEFF) {
        $localText = $localText.Substring(1)
    }

    if ($null -ne $ProgressWindow) { Set-StartupStatus -Window $ProgressWindow -Text 'Validating your local preview library XML...' }
    [xml]$parsedLocal = $localText
    $topLevelCount = @($parsedLocal.DocumentElement.ChildNodes | Where-Object { $_.LocalName -eq 'PreviewClass' }).Count

    $matches = [regex]::Matches($localText, $PreviewBlockPattern, $RegexOptions)
    if ($matches.Count -ne $topLevelCount) {
        throw "Preview scan mismatch in local LORPreviews.xml. Raw blocks=$($matches.Count), parsed top-level previews=$topLevelCount"
    }

    if ($null -ne $ProgressWindow) { Set-StartupStatus -Window $ProgressWindow -Text 'Checking preview identities and duplicates...' }
    $localById = @{}
    foreach ($match in $matches) {
        $previewId = $match.Groups['id'].Value.ToLowerInvariant()
        if (-not $localById.ContainsKey($previewId)) {
            $localById[$previewId] = @()
        }
        $localById[$previewId] += [pscustomobject]@{
            Start = $match.Index
            End   = $match.Index + $match.Length
            Raw   = $match.Value
        }
    }

    foreach ($previewId in $MasterRecords.Keys) {
        if ($localById.ContainsKey($previewId) -and @($localById[$previewId]).Count -ne 1) {
            throw "Duplicate controlled PreviewID found locally: $previewId"
        }
    }

    $unmanagedIds = @($localById.Keys | Where-Object { -not $MasterRecords.ContainsKey($_) })
    $unmanagedBefore = @{}
    foreach ($previewId in $unmanagedIds) {
        $unmanagedBefore[$previewId] = @($localById[$previewId] | ForEach-Object { Get-Sha256String $_.Raw })
    }

    $newline = Get-NewlineStyle $localText
    $rows = @()
    $replacements = @()
    $additions = @()

    $approvedRecords = @($MasterRecords.Values | Sort-Object Name)
    $compareIndex = 0
    foreach ($approved in $approvedRecords) {
        $compareIndex += 1
        if ($null -ne $ProgressWindow) {
            Set-StartupStatus -Window $ProgressWindow -Text (
                "Comparing this PC with master preview {0} of {1}: {2}" -f $compareIndex, $approvedRecords.Count, $approved.Name
            )
        }

        $previewId = $approved.PreviewId

        if (-not $localById.ContainsKey($previewId)) {
            $rows += [pscustomobject]@{
                Action                 = 'ADD_IN_CANDIDATE'
                Preview_ID             = $previewId
                Approved_Name          = $approved.Name
                Local_Name             = ''
                Approved_Revision      = $approved.Revision
                Local_Revision         = ''
                Approved_Semantic_Hash = $approved.SemanticHash
                Local_Semantic_Hash    = ''
            }
            $additions += $approved.Raw
            continue
        }

        $block = @($localById[$previewId])[0]
        $localRecord = Get-PreviewRecord -Raw $block.Raw -Source $LocalPath

        if ($localRecord.SemanticHash -eq $approved.SemanticHash) {
            if ($localRecord.Revision -eq $approved.Revision) {
                $action = 'NOOP'
            }
            else {
                $action = 'NOOP_REVISION_ONLY'
            }
        }
        else {
            $action = 'REPLACE_IN_CANDIDATE'
            $lineStart = $localText.LastIndexOf("`n", [Math]::Max(0, $block.Start - 1)) + 1
            $indent = $localText.Substring($lineStart, $block.Start - $lineStart)
            $replacement = Add-IndentToFragment $approved.Raw $indent $newline
            $replacements += [pscustomobject]@{
                Start = $block.Start
                End = $block.End
                Raw = $replacement
            }
        }

        $rows += [pscustomobject]@{
            Action                 = $action
            Preview_ID             = $previewId
            Approved_Name          = $approved.Name
            Local_Name             = $localRecord.Name
            Approved_Revision      = $approved.Revision
            Local_Revision         = $localRecord.Revision
            Approved_Semantic_Hash = $approved.SemanticHash
            Local_Semantic_Hash    = $localRecord.SemanticHash
        }
    }

    if ($null -ne $ProgressWindow) { Set-StartupStatus -Window $ProgressWindow -Text 'Building the proposed preview update...' }
    $candidate = $localText

    foreach ($replacement in @($replacements | Sort-Object Start -Descending)) {
        $candidate = $candidate.Substring(0, $replacement.Start) + $replacement.Raw + $candidate.Substring($replacement.End)
    }

    if ($additions.Count -gt 0) {
        $close = [regex]::Match($candidate, '</root\s*>\s*$', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if (-not $close.Success) {
            throw 'Could not locate closing </root> while adding controlled previews.'
        }

        $first = [regex]::Match($candidate, $PreviewBlockPattern, $RegexOptions)
        if ($first.Success) {
            $lineStart = $candidate.LastIndexOf("`n", [Math]::Max(0, $first.Index - 1)) + 1
            $childIndent = $candidate.Substring($lineStart, $first.Index - $lineStart)
        }
        else {
            $childIndent = '  '
        }

        $inserted = ''
        foreach ($fragment in $additions) {
            $normalized = $fragment.Replace("`r`n", "`n").Replace("`r", "`n")
            $lines = $normalized -split "`n", -1
            $indented = @($childIndent + $lines[0])
            for ($i = 1; $i -lt $lines.Count; $i++) {
                $indented += ($childIndent + $lines[$i])
            }
            $inserted += ($indented -join $newline) + $newline
        }

        $candidate = $candidate.Substring(0, $close.Index) + $inserted + $candidate.Substring($close.Index)
    }

    if ($null -ne $ProgressWindow) { Set-StartupStatus -Window $ProgressWindow -Text 'Verifying the proposed update and personal-preview preservation...' }
    # Validate the candidate after every change.
    [xml]$candidateXml = $candidate
    $candidateMatches = [regex]::Matches($candidate, $PreviewBlockPattern, $RegexOptions)
    $candidateById = @{}
    foreach ($match in $candidateMatches) {
        $previewId = $match.Groups['id'].Value.ToLowerInvariant()
        if (-not $candidateById.ContainsKey($previewId)) { $candidateById[$previewId] = @() }
        $candidateById[$previewId] += $match.Value
    }

    $candidateCheckIndex = 0
    foreach ($approved in $MasterRecords.Values) {
        $candidateCheckIndex += 1
        if ($null -ne $ProgressWindow -and (($candidateCheckIndex -eq 1) -or ($candidateCheckIndex % 5 -eq 0))) {
            Set-StartupStatus -Window $ProgressWindow -Text (
                "Verifying the safe merged result {0} of {1}..." -f $candidateCheckIndex, $MasterRecords.Count
            )
        }

        if (-not $candidateById.ContainsKey($approved.PreviewId)) {
            throw "Candidate is missing controlled PreviewID $($approved.PreviewId): $($approved.Name)"
        }
        if (@($candidateById[$approved.PreviewId]).Count -ne 1) {
            throw "Candidate contains duplicate controlled PreviewID $($approved.PreviewId): $($approved.Name)"
        }
        $candidateRecord = Get-PreviewRecord -Raw (@($candidateById[$approved.PreviewId])[0]) -Source 'candidate'
        if ($candidateRecord.SemanticHash -ne $approved.SemanticHash) {
            throw "Candidate controlled content does not match master: $($approved.Name)"
        }
    }

    $unmanagedAfter = @{}
    foreach ($previewId in $unmanagedIds) {
        if (-not $candidateById.ContainsKey($previewId)) {
            throw "Candidate lost unmanaged PreviewID $previewId"
        }
        $unmanagedAfter[$previewId] = @($candidateById[$previewId] | ForEach-Object { Get-Sha256String $_ })
    }

    foreach ($previewId in $unmanagedIds) {
        $before = @($unmanagedBefore[$previewId]) -join '|'
        $after = @($unmanagedAfter[$previewId]) -join '|'
        if ($before -ne $after) {
            throw "Candidate changed unmanaged PreviewID $previewId"
        }
    }

    return [pscustomobject]@{
        OriginalHash   = ([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($bytes))).Replace('-', '')
        Candidate      = $candidate
        HadBom         = $hadBom
        Rows           = $rows
        LocalCount     = $matches.Count
        UnmanagedCount = $unmanagedIds.Count
    }
}

function Write-CandidateFile {
    param($Build, [string]$Path)

    $data = [System.Text.Encoding]::UTF8.GetBytes($Build.Candidate)
    if ($Build.HadBom) {
        $bom = [byte[]](0xEF,0xBB,0xBF)
        $combined = New-Object byte[] ($bom.Length + $data.Length)
        [Array]::Copy($bom, 0, $combined, 0, $bom.Length)
        [Array]::Copy($data, 0, $combined, $bom.Length, $data.Length)
        $data = $combined
    }
    [System.IO.File]::WriteAllBytes($Path, $data)
}

function Write-ActionReport {
    param($Rows, [string]$Path)
    $Rows | Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8
}

function Get-ActionCounts {
    param($Rows)
    return [pscustomobject]@{
        Noop = @($Rows | Where-Object Action -eq 'NOOP').Count
        RevisionOnly = @($Rows | Where-Object Action -eq 'NOOP_REVISION_ONLY').Count
        Replace = @($Rows | Where-Object Action -eq 'REPLACE_IN_CANDIDATE').Count
        Add = @($Rows | Where-Object Action -eq 'ADD_IN_CANDIDATE').Count
    }
}


function Set-StartupStatus {
    param(
        [Parameter(Mandatory=$true)]$Window,
        [Parameter(Mandatory=$true)][string]$Text
    )

    if ($null -ne $Window.Tag) {
        $Window.Tag.Text = $Text
    }

    $Window.Refresh()
    [System.Windows.Forms.Application]::DoEvents()
    Start-Sleep -Milliseconds 1
}


function Prepare-SyncWithStartup {
    $script:StartupPrepared = $null
    $script:StartupException = $null

    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Update your PC Previews to LOR Master Files - v0.2.7 Updated 2026-10-04'
    $form.StartPosition = 'CenterScreen'
    $form.Size = New-Object System.Drawing.Size(680, 285)
    $form.MinimumSize = $form.Size
    $form.MaximumSize = $form.Size
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.FormBorderStyle = 'FixedDialog'
    $form.ShowInTaskbar = $true
    $form.Add_Shown({
        $this.TopMost = $true
        $this.Activate()
        $this.BringToFront()

        $bringForwardTimer = New-Object System.Windows.Forms.Timer
        $bringForwardTimer.Interval = 750
        $bringForwardTimer.Add_Tick({
            $this.Stop()
            $form.TopMost = $false
            $this.Dispose()
        })
        $bringForwardTimer.Start()
    })
    $form.TopMost = $true
    if ($null -ne $script:AppIcon) {
        $form.Icon = $script:AppIcon
    }

    $title = New-Object System.Windows.Forms.Label
    $title.Text = 'Starting MSB Preview Update...'
    $title.Font = New-Object System.Drawing.Font(
        'Segoe UI',
        15,
        [System.Drawing.FontStyle]::Bold
    )
    $title.AutoSize = $true
    $title.Location = New-Object System.Drawing.Point(24, 22)
    [void]$form.Controls.Add($title)

    $sourceFolderLabel = New-Object System.Windows.Forms.Label
    $sourceFolderLabel.Text = 'Master folder: locating the accepted source...'
    $sourceFolderLabel.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $sourceFolderLabel.Size = New-Object System.Drawing.Size(620, 65)
    $sourceFolderLabel.Location = New-Object System.Drawing.Point(26, 68)
    [void]$form.Controls.Add($sourceFolderLabel)

    $status = New-Object System.Windows.Forms.Label
    $status.Text = 'Starting...'
    $status.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $status.AutoSize = $false
    $status.Size = New-Object System.Drawing.Size(620, 55)
    $status.Location = New-Object System.Drawing.Point(26, 140)
    [void]$form.Controls.Add($status)

    $progress = New-Object System.Windows.Forms.ProgressBar
    $progress.Style = [System.Windows.Forms.ProgressBarStyle]::Marquee
    $progress.MarqueeAnimationSpeed = 28
    $progress.Location = New-Object System.Drawing.Point(28, 215)
    $progress.Size = New-Object System.Drawing.Size(610, 20)
    [void]$form.Controls.Add($progress)

    $form.Tag = $status

    $form.Add_Shown({
        try {
            $this.Activate()
            $this.BringToFront()
            [System.Windows.Forms.Application]::DoEvents()

            Set-StartupStatus -Window $this -Text 'Finding the latest accepted LOR2DB reconciliation report...'
            $accepted = Get-LatestAcceptedReport -Folder $ReportFolder
            $sourceFolderLabel.Text = "Master folder being compared:`r`n$($accepted.SourceFolder)"
            $sourceFolderLabel.Refresh()

            Set-StartupStatus -Window $this -Text (
                "Loading the approved LOR master preview set from Run {0}..." -f $accepted.RunId
            )
            $master = Get-MasterRecords -Folder ([string]$accepted.SourceFolder) -ProgressWindow $this

            Set-StartupStatus -Window $this -Text (
                "Checking the approved master against Run {0}..." -f $accepted.RunId
            )
            Test-MasterAgainstReport -Report $accepted -Master $master -ProgressWindow $this

            Set-StartupStatus -Window $this -Text (
                "Comparing {0} controlled previews with this PC..." -f $master.Records.Count
            )
            $build = Build-SyncCandidate -MasterRecords $master.Records -LocalPath $LocalXml -ProgressWindow $this

            Set-StartupStatus -Window $this -Text 'Preparing the update review...'
            Write-CandidateFile -Build $build -Path $CandidateXml
            $build | Add-Member -NotePropertyName CandidateHash -NotePropertyValue (Get-FileHash -LiteralPath $CandidateXml).Hash
            Write-ActionReport -Rows $build.Rows -Path $CandidateCsv

            $script:StartupPrepared = [pscustomobject]@{
                Accepted = $accepted
                Master = $master
                Build = $build
            }
        }
        catch {
            $script:StartupException = $_
        }
        finally {
            $this.Hide()
            [System.Windows.Forms.Application]::DoEvents()
            $this.Close()
        }
    })

    [void]$form.ShowDialog()
    $form.Dispose()

    if ($null -ne $script:StartupException) {
        throw $script:StartupException
    }

    if ($null -eq $script:StartupPrepared) {
        throw 'The startup preparation did not return a sync result.'
    }

    return $script:StartupPrepared
}


function Test-SequencerClosed {
    # Installed executable verified on this PC: LORSequencer.exe.
    $running = @(Get-Process -ErrorAction Stop | Where-Object { $_.ProcessName -in @('LORSequencer', 'LORSequenceEditor') })
    return ($running.Count -eq 0)
}

function Show-ReviewDialog {
    param(
        [Parameter(Mandatory=$true)]$AcceptedReport,
        [Parameter(Mandatory=$true)]$Build
    )

    $counts = Get-ActionCounts $Build.Rows
    $changed = @($Build.Rows | Where-Object { $_.Action -in @('REPLACE_IN_CANDIDATE','ADD_IN_CANDIDATE') })

    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Update your PC Previews to LOR Master Files - v0.2.7 Updated 2026-10-04'
    $form.StartPosition = 'CenterScreen'
    $form.Size = New-Object System.Drawing.Size(760, 720)
    $form.MinimumSize = New-Object System.Drawing.Size(760, 720)

    $form.ShowInTaskbar = $true
    if ($null -ne $script:AppIcon) {
        $form.Icon = $script:AppIcon
    }
    $title = New-Object System.Windows.Forms.Label
    $title.Text = 'MSB LOR Preview Update'
    $title.Font = New-Object System.Drawing.Font('Segoe UI', 16, [System.Drawing.FontStyle]::Bold)
    $title.AutoSize = $true
    $title.Location = New-Object System.Drawing.Point(18, 16)
    $form.Controls.Add($title)

    $summary = New-Object System.Windows.Forms.Label
    $summary.Text = (
        "Accepted LOR2DB Run: {0}`r`nMaster source: {1}`r`n`r`n" +
        "Controlled previews: {2}`r`nAlready current: {3}`r`n" +
        "Revision-only differences (no action): {4}`r`n" +
        "Will be replaced: {5}`r`nWill be added: {6}`r`n" +
        "Personal/unmanaged previews preserved: {7}"
    ) -f $AcceptedReport.RunId, $AcceptedReport.SourceFolder, $Build.Rows.Count, $counts.Noop, $counts.RevisionOnly, $counts.Replace, $counts.Add, $Build.UnmanagedCount
    $summary.AutoSize = $true
    $summary.Location = New-Object System.Drawing.Point(20, 55)
    $summary.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $form.Controls.Add($summary)

    $listLabel = New-Object System.Windows.Forms.Label
    $listLabel.Text = 'Controlled MSB previews that will change:'
    $listLabel.AutoSize = $true
    $listLabel.Location = New-Object System.Drawing.Point(20, 195)
    $listLabel.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $form.Controls.Add($listLabel)

    $box = New-Object System.Windows.Forms.TextBox
    $box.Multiline = $true
    $box.ReadOnly = $true
    $box.ScrollBars = 'Vertical'
    $box.Font = New-Object System.Drawing.Font('Consolas', 9)
    $box.Location = New-Object System.Drawing.Point(20, 220)
    $box.Size = New-Object System.Drawing.Size(700, 230)
    $box.Anchor = 'Top,Left,Right,Bottom'

    if ($changed.Count -eq 0) {
        $box.Text = 'No controlled MSB previews need to be added or replaced.'
    }
    else {
        $lines = @()
        foreach ($row in $changed) {
            if ($row.Action -eq 'ADD_IN_CANDIDATE') {
                $lines += "ADD      $($row.Approved_Name)"
            }
            else {
                $lines += "REPLACE  $($row.Approved_Name)    local rev $($row.Local_Revision) -> master rev $($row.Approved_Revision)"
            }
        }
        $box.Text = $lines -join "`r`n"
    }
    $form.Controls.Add($box)

    $destination = New-Object System.Windows.Forms.Label
    $destination.Location = New-Object System.Drawing.Point(20, 458)
    $destination.Size = New-Object System.Drawing.Size(700, 45)
    $destination.Text = 'Update destination: C:\lor\CommonData\LORPreviews.xml'
    if ($ReviewOnly) {
        $destination.Text += "`r`nRETEST ONLY: checks and acknowledgements are tested; no changes will be installed."
    }
    $form.Controls.Add($destination)

    $closedCheck = New-Object System.Windows.Forms.CheckBox
    $closedCheck.Text = 'I have closed LOR Sequencer on this PC.'
    $closedCheck.AutoSize = $true
    $closedCheck.Location = New-Object System.Drawing.Point(22, 505)
    $closedCheck.Anchor = 'Left,Bottom'
    $form.Controls.Add($closedCheck)

    $overwriteCheck = New-Object System.Windows.Forms.CheckBox
    $overwriteCheck.Text = 'I acknowledge that an actual update will change C:\lor\CommonData\LORPreviews.xml: listed MSB previews will be added/replaced, personal previews preserved, and a backup created first.'
    $overwriteCheck.AutoSize = $false
    $overwriteCheck.Size = New-Object System.Drawing.Size(690, 70)
    $overwriteCheck.Location = New-Object System.Drawing.Point(22, 535)
    $overwriteCheck.Anchor = 'Left,Right,Bottom'

    $form.Controls.Add($overwriteCheck)

    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = 'Cancel'
    $cancel.Size = New-Object System.Drawing.Size(110, 34)
    $cancel.Location = New-Object System.Drawing.Point(480, 620)
    $cancel.Anchor = 'Right,Bottom'
    $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $form.Controls.Add($cancel)

    $update = New-Object System.Windows.Forms.Button
    $update.Text = 'Update PC Previews'
    $update.Size = New-Object System.Drawing.Size(140, 34)
    $update.Location = New-Object System.Drawing.Point(600, 620)
    $update.Anchor = 'Right,Bottom'
    $update.Enabled = $false
    if ($ReviewOnly) { $update.Text = 'Test Acknowledgements' }
    $form.Controls.Add($update)

    $refreshButton = {
        $update.Enabled = ($closedCheck.Checked -and $overwriteCheck.Checked)
    }
    $closedCheck.add_CheckedChanged($refreshButton)
    $overwriteCheck.add_CheckedChanged($refreshButton)
    & $refreshButton

    $update.Add_Click({
        if (-not (Test-SequencerClosed)) {
            Show-Message 'Close LOR Sequencer before continuing. Nothing was changed.' 'MSB Update Blocked' ([System.Windows.Forms.MessageBoxIcon]::Warning)
            return
        }
        $form.Tag = 'APPLY'
        $form.Close()
    })

    $form.AcceptButton = $update
    $form.CancelButton = $cancel
    [void]$form.ShowDialog()

    return ($form.Tag -eq 'APPLY')
}

function Install-Candidate {
    param(
        [string]$CandidatePath,
        [string]$LivePath,
        [Parameter(Mandatory=$true)][string]$ExpectedOriginalHash,
        [Parameter(Mandatory=$true)][string]$ExpectedCandidateHash
    )
    if (-not (Test-SequencerClosed)) { throw 'Close LOR Sequencer before applying the update.' }
    if ((Get-FileHash -LiteralPath $LivePath).Hash -ne $ExpectedOriginalHash) {
        throw 'Your local preview library changed after comparison. Nothing was installed. Close Sequencer and compare again.'
    }
    if ((Get-FileHash -LiteralPath $CandidatePath).Hash -ne $ExpectedCandidateHash) {
        throw 'The proposed update changed after review. Nothing was installed. Compare again.'
    }
    [xml]$validated = [IO.File]::ReadAllText($CandidatePath)
    if ($validated.DocumentElement.Name -ne 'root') { throw 'Proposed preview library has an unexpected root.' }
    $stamp = (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + [guid]::NewGuid().ToString('N')
    $backupFolder = Join-Path (Split-Path -Parent $LivePath) 'MSB_Preview_Sync_Backups'
    New-Item -ItemType Directory -Path $backupFolder -Force | Out-Null
    $backup = Join-Path $backupFolder ("LORPreviews.before-msb-sync-{0}.xml" -f $stamp)
    $installing = "$LivePath.msb-sync-installing-$stamp"
    try {
        Copy-Item -LiteralPath $CandidatePath -Destination $installing -ErrorAction Stop
        if ((Get-FileHash -LiteralPath $installing).Hash -ne $ExpectedCandidateHash) { throw 'Installation copy does not match the reviewed update.' }
        if (-not (Test-SequencerClosed)) { throw 'LOR Sequencer reopened. Nothing was installed.' }
        if ((Get-FileHash -LiteralPath $LivePath).Hash -ne $ExpectedOriginalHash) { throw 'Local library changed. Compare again; nothing was installed.' }
        # Atomically preserve the actual displaced original, not an earlier copy.
        [IO.File]::Replace($installing, $LivePath, $backup)
        if ((Get-FileHash -LiteralPath $backup).Hash -ne $ExpectedOriginalHash) {
            $rejected = "$backup.rejected-update"
            [IO.File]::Replace($backup, $LivePath, $rejected)
            throw 'Local library changed during installation. The displaced library was restored; compare again.'
        }
        if ((Get-FileHash -LiteralPath $LivePath).Hash -ne $ExpectedCandidateHash) { throw "Installed file changed unexpectedly. Preserve backup: $backup" }
        return $backup
    }
    finally {
        if (Test-Path -LiteralPath $installing) { Remove-Item -LiteralPath $installing -Force }
    }
}

function Write-SharedLog {
    param(
        $Report,
        $Build,
        [string]$Result,
        [string]$Backup = ''
    )

    New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $safeUser = ($env:USERNAME -replace '[^A-Za-z0-9_.-]', '_')
    $safeComputer = ($env:COMPUTERNAME -replace '[^A-Za-z0-9_.-]', '_')
    $path = Join-Path $LogFolder ("sync-{0}-{1}-{2}.txt" -f $safeComputer, $safeUser, $stamp)
    $counts = Get-ActionCounts $Build.Rows

    @(
        "MSB LOR Preview Sync v0.2.7"
        "Deployment identity: $(if (Test-Path -LiteralPath (Join-Path $Root 'DEPLOYMENT.json')) { Get-Content -LiteralPath (Join-Path $Root 'DEPLOYMENT.json') -Raw } else { 'UNVERIFIED' })"
        "Local file: $LocalXml"
        "Before SHA256: $($Build.OriginalHash)"
        "After/current SHA256: $((Get-FileHash -LiteralPath $LocalXml).Hash)"
        "Reviewed candidate SHA256: $($Build.CandidateHash)"
        "Timestamp: $(Get-Date -Format o)"
        "Computer: $env:COMPUTERNAME"
        "User: $env:USERNAME"
        "Result: $Result"
        "LOR2DB Run: $($Report.RunId)"
        "Master folder: $($Report.SourceFolder)"
        "Controlled previews: $($Build.Rows.Count)"
        "NOOP: $($counts.Noop)"
        "Revision-only: $($counts.RevisionOnly)"
        "Replaced: $($counts.Replace)"
        "Added: $($counts.Add)"
        "Unmanaged/personal preserved: $($Build.UnmanagedCount)"
        "Backup: $Backup"
    ) | Set-Content -LiteralPath $path -Encoding UTF8
}

try {
    $prepared = Prepare-SyncWithStartup
    $accepted = $prepared.Accepted
    $master = $prepared.Master
    $build = $prepared.Build
    $counts = Get-ActionCounts -Rows $build.Rows

    if ($counts.Replace -eq 0 -and $counts.Add -eq 0) {
        Write-SharedLog -Report $accepted -Build $build -Result 'CURRENT'
        Show-Message (
            "Your MSB previews are already current.`r`n`r`n" +
            "Accepted LOR2DB Run: $($accepted.RunId)`r`n" +
            "Controlled previews: $($build.Rows.Count)`r`n" +
            "Revision-only differences ignored: $($counts.RevisionOnly)`r`n" +
            "Personal/unmanaged previews preserved: $($build.UnmanagedCount)"
        ) 'Update your PC Previews to LOR Master Files - v0.2.7 Updated 2026-10-04' ([System.Windows.Forms.MessageBoxIcon]::Information)
        exit 0
    }

    if ($AuditOnly -and -not $ReviewOnly) {
        Write-SharedLog -Report $accepted -Build $build -Result 'AUDIT_ONLY'
        Show-Message (
            "Your PC needs an MSB preview update.`r`n`r`n" +
            "Will replace: $($counts.Replace)`r`n" +
            "Will add: $($counts.Add)`r`n" +
            "Personal/unmanaged previews preserved: $($build.UnmanagedCount)`r`n`r`n" +
            "Audit-only mode did not change your PC."
        ) 'MSB Preview Audit' ([System.Windows.Forms.MessageBoxIcon]::Warning)
        exit 0
    }
    $approved = Show-ReviewDialog -AcceptedReport $accepted -Build $build
    if (-not $approved) {
        Write-SharedLog -Report $accepted -Build $build -Result 'CANCELLED'
        exit 0
    }

    if ($ReviewOnly) {
        Write-SharedLog -Report $accepted -Build $build -Result 'REVIEW_ONLY_PASSED'
        Show-Message 'Acknowledgements and Sequencer check passed. Retest only: your live previews were not changed.' 'MSB Acceptance Test' ([System.Windows.Forms.MessageBoxIcon]::Information)
        exit 0
    }
    $deploymentPath = Join-Path $Root 'DEPLOYMENT.json'
    if (-not (Test-Path -LiteralPath $deploymentPath)) { throw 'Committed deployment identity is missing. Nothing was installed.' }
    $deployment = Get-Content -LiteralPath $deploymentPath -Raw | ConvertFrom-Json
    if ($deployment.status -ne 'LAPTOP_ACCEPTANCE' -or $deployment.version -ne '0.2.7' -or $deployment.commit -notmatch '^[0-9a-f]{40}$') { throw 'Deployment identity is not a laptop acceptance checkpoint.' }
    if ((Get-FileHash -LiteralPath $MyInvocation.MyCommand.Path).Hash -ne $deployment.script_sha256) { throw 'Program does not match its committed deployment identity.' }
    Write-SharedLog -Report $accepted -Build $build -Result 'APPROVED_PENDING_INSTALL'
    $backup = Install-Candidate -CandidatePath $CandidateXml -LivePath $LocalXml -ExpectedOriginalHash $build.OriginalHash -ExpectedCandidateHash $build.CandidateHash
    Write-SharedLog -Report $accepted -Build $build -Result 'APPLIED' -Backup $backup

    Show-Message (
        "MSB preview update completed successfully.`r`n`r`n" +
        "Controlled previews updated from LOR2DB Run $($accepted.RunId).`r`n" +
        "Replaced: $($counts.Replace)`r`n" +
        "Added: $($counts.Add)`r`n" +
        "Personal/unmanaged previews preserved: $($build.UnmanagedCount)`r`n`r`n" +
        "Backup created:`r`n$backup`r`n`r`n" +
        "You may open Light-O-Rama now."
    ) 'Update Complete' ([System.Windows.Forms.MessageBoxIcon]::Information)
}
catch {
    $message = $_.Exception.Message
    try {
        New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null
        $detailPath = Join-Path $LogFolder 'powershell-error-latest.log'
        @(
            "MSB Preview Update PowerShell diagnostic"
            "Timestamp: $(Get-Date -Format o)"
            "Message: $message"
            "Exception: $($_.Exception.GetType().FullName)"
            "Position: $($_.InvocationInfo.PositionMessage)"
            "Stack: $($_.ScriptStackTrace)"
        ) | Set-Content -LiteralPath $detailPath -Encoding UTF8
    }
    catch {
        $detailPath = Join-Path $Root 'powershell-error-latest.log'
    }

    Show-Message (
        "The MSB preview update was BLOCKED.`r`n`r`n$message`r`n`r`n" +
        "Nothing was intentionally changed.`r`n`r`nDiagnostic log:`r`n$detailPath"
    ) 'MSB Preview Update Blocked' ([System.Windows.Forms.MessageBoxIcon]::Error)
    # Exit code 20 means the PowerShell program already displayed the operator error.
    # The hidden launcher must not show a second duplicate error dialog.
    exit 20
}
