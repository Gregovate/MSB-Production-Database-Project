﻿# MSB Preview Sync production-layout migration
# Issue #299
# Administrator-only. This does not modify the user's local LOR preview library.

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$TargetRoot = 'G:\Shared drives\MSB Database\UserPreviewStaging\LOR2DB_2PC_Sync'
$SupportName = 'MSB Preview Sync Support'
$SupportRoot = Join-Path $TargetRoot $SupportName
$ShortcutName = 'Update your PC Previews to LOR Master Files.lnk'
$ShortcutPath = Join-Path $TargetRoot $ShortcutName
$InstructionsName = 'READ ME - Update your PC Previews.txt'
$InstructionsPath = Join-Path $TargetRoot $InstructionsName
$PowerShellPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$Timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$BackupRoot = Join-Path $SupportRoot ('migration-backups\' + $Timestamp)
$MigrationLog = Join-Path $env:TEMP ('MSB-Preview-Sync-Production-Layout-' + $Timestamp + '.log')

$InstructionsText = @'
MSB LOR Preview Update
======================

Use this before starting work on MSB Light-O-Rama sequences.

1. CLOSE LIGHT-O-RAMA
   Make sure the Light-O-Rama Sequencer is closed.

2. DOUBLE-CLICK
   "Update your PC Previews to LOR Master Files"

3. WAIT FOR THE CHECK TO FINISH
   The updater automatically finds the latest accepted LOR2DB production
   reconciliation and the correct approved versioned master-preview folder.
   You do not select a version or folder.

4. REVIEW THE RESULTS
   The window will show:
   - accepted LOR2DB Run
   - approved master source
   - controlled previews already current
   - controlled previews that will be added
   - controlled previews that will be replaced
   - personal/unmanaged previews that will be preserved

5. APPROVE THE UPDATE
   Confirm Light-O-Rama is closed.
   If controlled MSB previews will be replaced, acknowledge the warning.
   Click "Update PC Previews".

6. REOPEN LIGHT-O-RAMA
   After the updater reports success, reopen Light-O-Rama and continue working.

IMPORTANT
---------
- Do NOT manually import the full MSB preview library.
- Do NOT copy another programmer's LORPreviews.xml.
- Do NOT choose a "Database Previews Vx.x.x" folder yourself.
- Personal/imported/store previews are preserved.
- The updater gets the approved master location from the latest COMPLETED
  LOR2DB reconciliation report.
- If the approved source is missing or does not match the LOR2DB evidence,
  the updater stops rather than guessing.

If the updater reports BLOCKED or FAILED, stop and contact the MSB database administrator.
'@

function Write-Log {
    param([Parameter(Mandatory=$true)][string]$Message)
    Add-Content -LiteralPath $MigrationLog -Value (
        '{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    ) -Encoding UTF8
}

function Show-Info {
    param([string]$Message)
    Add-Type -AssemblyName System.Windows.Forms
    [void][System.Windows.Forms.MessageBox]::Show(
        $Message,
        'MSB Preview Sync Production Setup',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    )
}

function Show-Error {
    param([string]$Message)
    Add-Type -AssemblyName System.Windows.Forms
    [void][System.Windows.Forms.MessageBox]::Show(
        $Message,
        'MSB Preview Sync Production Setup - BLOCKED',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    )
}

function Get-LatestCompletedReportInfo {
    param([Parameter(Mandatory=$true)][string]$ReportFolder)

    if (-not (Test-Path -LiteralPath $ReportFolder -PathType Container)) {
        throw "LOR2DB report folder is missing: $ReportFolder"
    }

    $candidates = @()
    foreach ($file in @(Get-ChildItem -LiteralPath $ReportFolder -Filter '*.html' -File)) {
        $html = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8

        if ($html -notmatch 'data-report-outcome\s*=\s*["'']COMPLETED["'']') {
            continue
        }

        $runId = $null
        if ($html -match '(?is)LOR Production Reconciliation Report\s*[—-]\s*Run\s+(\d+)') {
            $runId = [int]$Matches[1]
        }
        elseif ($html -match '(?is)\bRun\s+(\d+)\b') {
            $runId = [int]$Matches[1]
        }

        if ($null -eq $runId) {
            continue
        }

        $sourceFolder = $null
        if ($html -match '(?i)(G:\\Shared drives\\MSB Database\\Database Previews V[0-9.]+)') {
            $sourceFolder = $Matches[1]
        }

        if (-not $sourceFolder) {
            $plain = [System.Net.WebUtility]::HtmlDecode(($html -replace '<[^>]+>', ' '))
            if ($plain -match '(?is)Source\s+folder\s*[:\s]+(G:\\Shared drives\\MSB Database\\Database Previews V[0-9.]+)') {
                $sourceFolder = $Matches[1]
            }
        }

        if (-not $sourceFolder) {
            throw "Completed Run $runId report does not expose a readable versioned Source folder: $($file.FullName)"
        }

        $candidates += [pscustomobject]@{
            RunId = $runId
            SourceFolder = $sourceFolder
            ReportPath = $file.FullName
        }
    }

    if ($candidates.Count -eq 0) {
        throw "No COMPLETED LOR2DB reconciliation report was found in: $ReportFolder"
    }

    return $candidates | Sort-Object RunId -Descending | Select-Object -First 1
}

function Copy-ItemForBackup {
    param(
        [Parameter(Mandatory=$true)][string]$Source,
        [Parameter(Mandatory=$true)][string]$DestinationRoot
    )

    if (-not (Test-Path -LiteralPath $Source)) {
        return
    }

    $dest = Join-Path $DestinationRoot (Split-Path -Leaf $Source)

    if (Test-Path -LiteralPath $Source -PathType Container) {
        Copy-Item -LiteralPath $Source -Destination $dest -Recurse -Force
    }
    else {
        Copy-Item -LiteralPath $Source -Destination $dest -Force
    }
}

function Move-KnownItem {
    param([Parameter(Mandatory=$true)][string]$Name)

    $source = Join-Path $TargetRoot $Name
    if (-not (Test-Path -LiteralPath $source)) {
        return
    }

    $destination = Join-Path $SupportRoot $Name

    if (Test-Path -LiteralPath $source -PathType Container) {
        if (-not (Test-Path -LiteralPath $destination -PathType Container)) {
            [void][System.IO.Directory]::CreateDirectory($destination)
        }

        foreach ($child in @(Get-ChildItem -LiteralPath $source -Force)) {
            $childDest = Join-Path $destination $child.Name
            if (Test-Path -LiteralPath $childDest) {
                $childDest = Join-Path $destination (
                    $child.Name + '.migrated-' + (Get-Date -Format 'yyyyMMdd-HHmmssfff')
                )
            }
            Move-Item -LiteralPath $child.FullName -Destination $childDest
        }

        Remove-Item -LiteralPath $source -Force
    }
    else {
        if (Test-Path -LiteralPath $destination) {
            $sourceHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
            $destHash = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
            if ($sourceHash -eq $destHash) {
                Remove-Item -LiteralPath $source -Force
                return
            }

            $destination = $destination + '.migrated-' + (Get-Date -Format 'yyyyMMdd-HHmmssfff')
        }

        Move-Item -LiteralPath $source -Destination $destination
    }
}

try {
    Write-Log 'Starting production-layout migration.'

    if (-not (Test-Path -LiteralPath $TargetRoot -PathType Container)) {
        throw "Shared deployment folder was not found: $TargetRoot"
    }

    if (-not (Test-Path -LiteralPath $PowerShellPath -PathType Leaf)) {
        throw "Windows PowerShell was not found: $PowerShellPath"
    }

    foreach ($name in @(
        'Update_MSB_Previews.ps1',
        'MSB Preview Update Tree v2.ico',
        'DEPLOYMENT.json',
        'LOR2DB_Reports'
    )) {
        $current = Join-Path $TargetRoot $name
        $alreadyMoved = Join-Path $SupportRoot $name
        if (-not (Test-Path -LiteralPath $current) -and
            -not (Test-Path -LiteralPath $alreadyMoved)) {
            throw "Required deployed item is missing: $name"
        }
    }

    $knownNames = @(
        $ShortcutName,
        $InstructionsName,
        $SupportName,
        'desktop.ini',
        'deployment-backups',
        'logs',
        'LOR2DB_Reports',
        'tools',
        'CONTROLLED_PC_TEST.txt',
        'DEPLOYMENT.json',
        'Install MSB Controlled PC Test.vbs',
        'Install MSB Preview Update Shortcut.vbs',
        'Launch_Update_MSB_Previews.vbs',
        'MSB Preview Update - DIAGNOSTIC.cmd',
        'MSB Preview Update Tree v2.ico',
        'MSB Preview Update.ico',
        'Update your PC Previews to LOR Master Files.cmd',
        'Update_MSB_Previews.ps1',
        'VERSION.txt',
        'README.txt'
    )

    $unexpected = @(
        Get-ChildItem -LiteralPath $TargetRoot -Force |
        Where-Object { $knownNames -notcontains $_.Name } |
        Select-Object -ExpandProperty Name
    )

    if ($unexpected.Count -gt 0) {
        throw "Unexpected item(s) are present. Nothing was moved.`r`n`r`n$($unexpected -join "`r`n")"
    }

    if (-not (Test-Path -LiteralPath $SupportRoot -PathType Container)) {
        [void][System.IO.Directory]::CreateDirectory($SupportRoot)
    }
    if (-not (Test-Path -LiteralPath $BackupRoot -PathType Container)) {
        [void][System.IO.Directory]::CreateDirectory($BackupRoot)
    }

    foreach ($item in @(Get-ChildItem -LiteralPath $TargetRoot -Force)) {
        if ($item.Name -ne $SupportName) {
            Copy-ItemForBackup -Source $item.FullName -DestinationRoot $BackupRoot
        }
    }

    Write-Log "Backup captured: $BackupRoot"

    foreach ($name in @(
        'deployment-backups',
        'logs',
        'LOR2DB_Reports',
        'tools',
        'CONTROLLED_PC_TEST.txt',
        'DEPLOYMENT.json',
        'Install MSB Controlled PC Test.vbs',
        'Install MSB Preview Update Shortcut.vbs',
        'Launch_Update_MSB_Previews.vbs',
        'MSB Preview Update - DIAGNOSTIC.cmd',
        'MSB Preview Update Tree v2.ico',
        'MSB Preview Update.ico',
        'Update your PC Previews to LOR Master Files.cmd',
        'Update_MSB_Previews.ps1',
        'VERSION.txt',
        'README.txt'
    )) {
        Move-KnownItem -Name $name
    }

    $scriptPath = Join-Path $SupportRoot 'Update_MSB_Previews.ps1'
    $iconPath = Join-Path $SupportRoot 'MSB Preview Update Tree v2.ico'
    $reportFolder = Join-Path $SupportRoot 'LOR2DB_Reports'
    $deploymentPath = Join-Path $SupportRoot 'DEPLOYMENT.json'

    foreach ($p in @($scriptPath, $iconPath, $deploymentPath)) {
        if (-not (Test-Path -LiteralPath $p -PathType Leaf)) {
            throw "Migration verification failed. Required support file is missing: $p"
        }
    }

    $accepted = Get-LatestCompletedReportInfo -ReportFolder $reportFolder
    if (-not (Test-Path -LiteralPath $accepted.SourceFolder -PathType Container)) {
        throw "Latest COMPLETED LOR2DB Run $($accepted.RunId) points to an unavailable master folder:`r`n$($accepted.SourceFolder)"
    }

    $masterFiles = @(Get-ChildItem -LiteralPath $accepted.SourceFolder -Filter '*.lorprev' -File)
    if ($masterFiles.Count -eq 0) {
        throw "The accepted master folder contains no .lorprev files:`r`n$($accepted.SourceFolder)"
    }

    Set-Content -LiteralPath $InstructionsPath -Value $InstructionsText -Encoding UTF8

    $shell = New-Object -ComObject WScript.Shell
    if (Test-Path -LiteralPath $ShortcutPath) {
        Remove-Item -LiteralPath $ShortcutPath -Force
    }

    $shortcut = $shell.CreateShortcut($ShortcutPath)
    $shortcut.TargetPath = $PowerShellPath
    $shortcut.Arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + $scriptPath + '"'
    $shortcut.WorkingDirectory = $SupportRoot
    $shortcut.Description = 'Update your PC Previews to LOR Master Files'
    $shortcut.WindowStyle = 7
    $shortcut.IconLocation = $iconPath + ',0'
    $shortcut.Save()

    if (-not (Test-Path -LiteralPath $ShortcutPath -PathType Leaf)) {
        throw 'Windows did not create the production shortcut.'
    }

    $visibleRoot = @(
        Get-ChildItem -LiteralPath $TargetRoot -Force |
        Where-Object { $_.Name -ne 'desktop.ini' } |
        Select-Object -ExpandProperty Name
    ) | Sort-Object

    $expectedVisible = @($SupportName, $ShortcutName, $InstructionsName) | Sort-Object

    if (($visibleRoot -join '|') -ne ($expectedVisible -join '|')) {
        throw "Production root cleanup did not finish cleanly.`r`nVisible items:`r`n$($visibleRoot -join "`r`n")"
    }

    $receipt = [ordered]@{
        schema_version = 1
        migrated_at = (Get-Date).ToString('o')
        target_root = $TargetRoot
        support_root = $SupportRoot
        shortcut = $ShortcutPath
        instructions = $InstructionsPath
        latest_completed_lor2db_run = $accepted.RunId
        accepted_master_source = $accepted.SourceFolder
        accepted_master_file_count = $masterFiles.Count
        migration_backup = $BackupRoot
        updater_sha256 = (Get-FileHash -LiteralPath $scriptPath -Algorithm SHA256).Hash.ToLowerInvariant()
        deployment_sha256 = (Get-FileHash -LiteralPath $deploymentPath -Algorithm SHA256).Hash.ToLowerInvariant()
        result = 'PASS'
    }

    $receipt | ConvertTo-Json -Depth 5 |
        Set-Content -LiteralPath (Join-Path $SupportRoot 'PRODUCTION_LAYOUT.json') -Encoding UTF8

    Write-Log "PASS. Latest COMPLETED LOR2DB Run $($accepted.RunId); master: $($accepted.SourceFolder)"

    Show-Info (
        "MSB Preview Sync production layout installed successfully.`r`n`r`n" +
        "Programmers now see only:`r`n" +
        "  Update your PC Previews to LOR Master Files`r`n" +
        "  READ ME - Update your PC Previews.txt`r`n" +
        "  MSB Preview Sync Support`r`n`r`n" +
        "Latest accepted LOR2DB Run: $($accepted.RunId)`r`n" +
        "Master source: $($accepted.SourceFolder)`r`n`r`n" +
        "No local LOR preview library was changed by this migration."
    )

    Start-Process explorer.exe -ArgumentList ('/select,"' + $ShortcutPath + '"')
    exit 0
}
catch {
    Write-Log ("BLOCKED: " + $_.Exception.Message)
    Show-Error (
        $_.Exception.Message + "`r`n`r`n" +
        "Nothing should be assumed cleaned up. Migration log:`r`n" +
        $MigrationLog
    )
    exit 2
}
